# Comment mettre ton site "Shoes Empire" en ligne (gratuit)

## Étape 1 — Vérifier le contenu
- Le fichier `index.html` contient ton site complet.
- Le dossier `images/` contient toutes les photos produits. **Ne renomme pas ces fichiers**, sinon les images ne s'afficheront plus.
- Tous les boutons "Commander" envoient vers WhatsApp au numéro +229 01 42 92 49 84. Vérifie que c'est le bon format sur https://wa.me — si le lien ne s'ouvre pas correctement, dis-le moi et je corrige.

## Étape 2 — Mise en ligne avec Netlify (recommandé, gratuit, 2 minutes)
1. Va sur https://app.netlify.com/drop
2. Glisse-dépose **tout le dossier** `shoesempire` (celui qui contient `index.html` et `images/`) dans la zone indiquée
3. Netlify te donne un lien du type `https://random-name-123.netlify.app` — ton site est en ligne !
4. (Optionnel) Dans Netlify, tu peux changer ce nom en quelque chose comme `shoesempire-cotonou.netlify.app` (Site settings → Change site name)

## Étape 3 — Ajouter un nom de domaine perso (optionnel, payant)
Si tu veux un nom comme `shoesempire.bj` ou `.com` :
1. Achète le nom sur un site comme Namecheap ou OVH (~5 000-10 000 FCFA/an)
2. Dans Netlify : Site settings → Domain management → Add custom domain
3. Suis les instructions pour connecter le domaine

## Pour modifier le site plus tard
- Prix, pointures, textes : ouvre `index.html` avec un éditeur de texte (Notepad, VS Code) et cherche la section `const products = [...]` vers la fin du fichier — c'est là que sont listés tous les produits.
- Nouvelles photos : ajoute-les dans le dossier `images/` et ajoute une ligne correspondante dans `products`.
- Après modification, ré-upload simplement le dossier sur Netlify Drop pour mettre à jour.

## À compléter
- 3 produits ("Air Jordan 4", "Air Jordan 6 Rings", "Asics Gel-NYC", "Nike Air Max style") sont marqués "Prix sur demande" car je n'ai pas encore le prix — donne-les moi et j'actualise.
- Les pointures sont pour l'instant "nous consulter" pour tous les modèles — donne-moi les tailles dispo par paire si tu veux que ce soit précis.
